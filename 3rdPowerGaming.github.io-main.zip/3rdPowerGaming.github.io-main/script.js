 function changeBodyBg(color){
        document.body.style.background = color;
    }
   
   
   function myFunction(){
    window.location.href = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"; 
   }
